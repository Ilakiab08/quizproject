Prosjekt 1 - Quiz 

Gruppe 1 : Emir, Andre, Tamizh

![Screenshot 2023-12-08 at 07 03 25](https://github.com/EmirB08/gruppeprosjekt-quiz/assets/142892269/093840e5-0159-4129-9df5-7b43b54a7755)
<img width="1349" alt="Screenshot 2023-12-08 at 09 05 30" src="https://github.com/EmirB08/gruppeprosjekt-quiz/assets/142892269/dd895d45-063d-4533-97db-f18a2e67be98">


Oppgaven vi fikk utdelt var å lage en quiz-webapp hvor vi skulle brukere JavaScript til å manipulere DOM og håndtere brukerinteraksjon. Vi bestemte oss for å lage en quiz hvor fokuset var på webutvikling med tre emner i fokus (HTML, CSS og JS). 
Vi designet i Figma en mal på hvordan vi ville at det skulle se ut og begynte så med med progammeringen av de ulike funksjonene vi skulle ha med.Oppgaven har gått bra og vi har tilfredstilt kravene for de ulike funksjonalitetene vi skulle ha med.



